﻿<?php
/**
 *	静默活体检测WebAPI接口调用示例接口文档(必看):https://doc.xfyun.cn/rest_api/%E9%9D%99%E9%BB%98%E6%B4%BB%E4%BD%93%E6%A3%80%E6%B5%8B.html
 * 上传人脸视频要求:支持mp4, .avi, .flv, .wmv, .mov, .rm格式视频，建议上传MP4格式,视频长度不小于3s,视频大小不应超过16M
 * (Very Important)创建完webapi应用添加合成服务之后一定要设置ip白名单，找到控制台--我的应用--设置ip白名单，如何设置参考：http://bbs.xfyun.cn/forum.php?mod=viewthread&tid=41891
 * 错误码链接：https://www.xfyun.cn/document/error-code (code返回错误码时必看)
 * @author iflytek
 */
class test{
	function xfyun(){
		    $daytime=strtotime('1970-1-1T00:00:00 UTC');
			// webapi 接口地址
		    $api = "http://api.xfyun.cn/v1/service/v1/image_identify/silent_detection";
			// 应用ID (必须为webapi类型应用，并开通静默活体检测服务，参考帖子如何创建一个webapi应用：http://bbs.xfyun.cn/forum.php?mod=viewthread&tid=36481)
		    $XAppid = "****";
			// 接口密钥(webapi类型应用开通静默活体检测服务后，控制台--我的应用---静默活体检测---相应服务的apikey)
		    $Apikey = "****";
		    $XCurTime =time();
		    $XParam ="";
		    $XCheckSum ="";
		    // 默认不返回base64编码后的图片文件流 
		    $Param= array(
				"get_image"=>false,
		    );
			// 视频路径地址,支持mp4, .avi, .flv, .wmv, .mov, .rm格式视频，建议上传MP4格式,视频长度不小于3s,视频大小不应超过16M
		    $filePath = "视频路径";
		    $fp = fopen($filePath, "rb");
		    $audioContent = fread($fp,filesize($filePath));
		    $audioBase64 = base64_encode($audioContent);
		    
		    $Post = array(
			  'file' => $audioBase64,
			);
			// 对param进行base64编码并组装http请求头
		    $XParam = base64_encode(json_encode($Param));
		    $XCheckSum = md5($Apikey.$XCurTime.$XParam);
		    $headers = array();
		    $headers[] = 'X-CurTime:'.$XCurTime;
		    $headers[] = 'X-Param:'.$XParam;
		    $headers[] = 'X-Appid:'.$XAppid;
		    $headers[] = 'X-CheckSum:'.$XCheckSum;
		    $headers[] = 'Content-Type:application/x-www-form-urlencoded; charset=utf-8';
		    echo $this->http_request($api, $Post, $headers);
		}

		/**
		 * 发送post请求
		 * @param string $url 请求地址
		 * @param array $post_data post键值对数据
		 * @return string
		 */
		function http_request($url, $post_data, $headers) {		 
		  $postdata = http_build_query($post_data);
		  $options = array(
		    'http' => array(
		      'method' => 'POST',
		      'header' => $headers,
		      'content' => $postdata,
		      'timeout' => 15 * 60 // 超时时间（单位:s）
		    )
		  );
		  $context = stream_context_create($options);
		  $result = file_get_contents($url, false, $context);
		// 错误码链接：https://www.xfyun.cn/document/error-code (code返回错误码时必看)
		  echo $result; 
			
		  return "success";
		}
}
$a = new test();
$a->xfyun();
?>